# Next.js kit

Puts the chat widget on a Next.js site, and pushes the site's products and pages to the service. It needs no WordPress and no WooCommerce, and no change to the service.

| You have | What you use |
|---|---|
| Next.js in front of WordPress and WooCommerce | The WordPress plugin as usual, plus [the widget](#2-add-the-widget). Turn off the plugin's own widget output by keeping "Show widget to administrators only" ticked, or the WordPress site gets it too. |
| A site with its own products | [The widget](#2-add-the-widget) and [the catalog push](#3-push-your-products-and-pages) |
| A content site with no products | [The widget](#2-add-the-widget) and [pages only](#3-push-your-products-and-pages). Provision it without the product tools. |

Known limits are in [What it does not do yet](#what-it-does-not-do-yet). Read them before you promise a client anything.

## 1. Create the store (on the server)

As `deploy`, in `~/wp-chatbot`. `TENANT_ID` is your one tenant, so the store appears under your dashboard login. Use `--tenant-id`, not `--tenant-name`.

```sh
dc run --rm api python -m app.ops.cli provision-store \
    --tenant-id TENANT_ID \
    --domain your-site.example \
    --origin https://www.your-site.example \
    --scope catalog:sync --scope webhooks:write \
    --widget-scope chat \
    --tool search_products --tool get_product --tool get_store_policy
```

It prints the publishable key, the plugin token and the webhook secret **once**. Put the token and the secret straight into your password manager.

**`--origin` must be the exact address shoppers see.** `https://example.com` and `https://www.example.com` are different origins. If one is missing, the service refuses the widget and it shows "You're offline". Add one `--origin` for each address, or redirect everything to one address. Vercel preview addresses change per deploy, so the widget works only on addresses you listed.

Then, in the dashboard, switch **Offers** off for the new store (a new store starts with it on).

## 2. Add the widget

Install the package from its file (it is not on npm), and copy the widget into `public/`. Build the file with `npm pack` in this folder after `npm run build`.

```sh
npm install ./wp-chatbot-nextjs-0.1.0.tgz
npx wpc-next-assets
```

Run `npx wpc-next-assets` again after every upgrade, or add it to your build. The two files must be served from your own site: the widget refuses a panel script from anywhere else.

Set these (see [example/.env.example](example/.env.example)):

```sh
NEXT_PUBLIC_WPC_API_BASE=https://api.nuvorro.store
NEXT_PUBLIC_WPC_PUBLISHABLE_KEY=pk_...
NEXT_PUBLIC_WPC_SITE_URL=https://www.your-site.example
```

App Router, in the root layout (`app/layout.tsx`):

```tsx
import { ChatbotWidget } from "@wp-chatbot/nextjs";

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>
        {children}
        <ChatbotWidget displayName="Shop helper" />
      </body>
    </html>
  );
}
```

Pages Router: the same `<ChatbotWidget />` in `pages/_app.tsx`.

Put it in the layout, once, so it is in the page the server sends. It also takes `greeting`, `position`, `colors`, `assetsPath` and `nonce`. A wrong setting stops you with its name while you develop; in production it logs the problem and shows no widget, so it can never take your site down.

**If your site sends a Content-Security-Policy,** allow your API address in `connect-src`, pass your `nonce`, keep `'self'` in `script-src` (the widget loads its panel from your site), and allow inline styles for the widget's style element in `style-src`. Allow your product image hosts in `img-src`. This list comes from reading the widget; it has not been run against a real policy yet, so test it.

## 3. Push your products and pages

This runs **on your server only**. The token and the secret must never reach a browser, so `@wp-chatbot/nextjs/server` needs the Node.js runtime and a client bundle that imports it fails to build. Never prefix these with `NEXT_PUBLIC_`.

```ts
import { createRelay } from "@wp-chatbot/nextjs/server";

const relay = createRelay({
  apiBase: process.env.NEXT_PUBLIC_WPC_API_BASE!,
  pluginToken: process.env.WPC_PLUGIN_TOKEN!,
  webhookSecret: process.env.WPC_WEBHOOK_SECRET!,
});

await relay.checkConnection(); // proves the address and the token work
```

### Pushing your catalog

```ts
const result = await relay.pushProducts(products, { onProgress: (n) => console.log(n) });
// { sent: 120, duplicates: 0, failed: [{ id: "tee", error: "wp-chatbot: name is empty or too long" }] }
```

A product looks like this:

```ts
{
  id: "red-mug",                  // your own id: a positive number, or text
  name: "Red Mug",
  url: "https://www.your-site.example/products/red-mug",
  price: "12.50",                 // what a shopper pays now
  regularPrice: "15.00",          // optional, with salePrice, saleFrom, saleTo
  salePrice: "12.50",
  saleTo: "2026-12-31T00:00:00Z",
  sku: "MUG-RED",
  description: "<p>Holds 300 ml.</p>",
  categories: ["Mugs"],
  attributes: { Colour: ["Red"] },
  imageUrl: "https://www.your-site.example/red.jpg", // https only
  stock: { status: "instock", quantity: 7 },         // or "outofstock", "onbackorder"
  updatedAt: "2026-10-01T10:00:00Z",                 // when it last changed: see below
  variations: [                                      // the complete list, each time
    { id: "red-mug-l", attributes: { Size: "L" }, price: "14.00", stock: { status: "instock", quantity: 3 } },
  ],
}
```

Three rules the service enforces, so get them right:

- **`updatedAt` must move forward when a product changes.** The service ignores a product older than the copy it holds. Sending the same product with the same `updatedAt` twice is a harmless duplicate, so a change without a new `updatedAt` is lost.
- **Removed products are not detected.** Call `relay.deleteProduct(id)` when one is removed. To bring a removed product back, send it with an `updatedAt` later than the removal.
- **It goes at about 100 products a minute,** because the service allows 120 plugin calls a minute per store. A catalog of 3,000 takes about 30 minutes, so run a first sync from a script or a worker, not from a request handler (serverless functions will time out). After that, send only what changed.

### Pushing your pages

Pages are what the assistant answers policy and FAQ questions from.

```ts
await relay.syncPages([
  { id: "/returns", kind: "policy", title: "Returns", url: "https://www.your-site.example/returns",
    html: "<p>Within 30 days.</p>", updatedAt: "2026-10-01T10:00:00Z" },
]);
```

Pass **every** public page each time: the service removes any page not on the list, and asks only for the ones it is missing or holds an older copy of. `url` must be on an origin the store was provisioned with, or the answer shows no link to it. Use `relay.upsertPage(page)` for one page, and `relay.listPages()` to see what the assistant can use. `published: false` removes a page, and its content is never sent. Send public pages only: nothing behind a login.

A complete route you can call from a cron job is in [example/app/api/chatbot-sync/route.ts](example/app/api/chatbot-sync/route.ts).

## What it does not do yet

These are planned in [Milestone 15, Phase 2](../../docs/milestones/milestone-15.md). They need a change to the service.

- **No currency symbol.** The currency reaches the service only through the WooCommerce sync, so a store fed by this kit shows prices as bare numbers (`12.50`, never a guessed `$`).
- **No order tracking, returns or customer sign-in.** Orders still assume WooCommerce. The kit is for answers: products, prices, stock and pages.
- **No "which product is this page about".** On a WordPress store the chat knows the product page it was opened on. The widget reads its config once, and Next.js changes pages without reloading.
- **No catalog reconcile.** The service cannot yet tell you which products it holds that you no longer sell.

Do not call `POST /v1/plugin/catalog/sync` or click anything that means "sync from WooCommerce" for these stores: that pulls from WooCommerce, which they do not have.

## Files

| Path | What |
|---|---|
| `src/ChatbotWidget.tsx`, `src/config.ts` | The widget component and its checked config. Safe in the browser. |
| `src/events.ts`, `src/relay.ts`, `src/server.ts` | The signed push to the service. Server only. |
| `bin/copy-assets.mjs` | `wpc-next-assets`: copies the widget into `public/`. |
| `example/` | A small App Router site, built for real by the checks. |
| `test/` | Kit tests, including the real built widget running on the kit's config. |

The checks, in Docker: `docker compose build nextjs-kit-tests && docker compose run --rm nextjs-kit-tests`. They need about 2.5 GB of free memory for the `next build` step. The events are fixed by [contracts/nextjs_event_vectors.json](../../contracts/nextjs_event_vectors.json), which the backend tests too.

---
Project overview and current progress: [PROGRESS.md](../../PROGRESS.md).
